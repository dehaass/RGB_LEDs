#!/usr/bin/python
# Filename: piSite.py
# Created: Feb 27, 2016
# Author: Stuart de Haas
# Last edit: Feb 27, 2016
#
#
# A script to help manage a webserver on a raspberry pi and to
# control an RGB LED strip lighting script

import profile
import sys
import getopt
import getpass
import cgi
import RGBpi

error = 'null'

print("Content-type: text/html\n\n")

print('<html><body><script>')
print('/*')

def main():

# Need to use global error
    global error

    ser = RGBpi.connectPi()
    if ser == "poop":
        print( "Serial connection failed :(")
        error = "Couldn't connect to the pi!"
        return
    else:
        print("Connected")


    argList = cgi.FieldStorage()

    for opt in argList.keys():
        #print("%s = %s" % (opt, argList[opt].value))
        if RGBpi.isAlive(ser) != True:
            print("The Arduino is not alive!")
            error = "Dead Arduino"
            break
        elif opt == '-a':
            RGBpi.changeSettings(ser, [-1, 250, 1, 1, 2, -1, -1, -1, 50, 9])
            break
        elif opt == '-l':
            RGBpi.sleepArd(ser)
            break
        elif opt == '-c':
            RGBpi.changeCol(ser, argList[opt].value)
            break
        elif opt == '-s':
            RGBpi.changeSeq(ser, argList[opt].value)
            break
        elif opt=='-r' or opt=='-g' or opt=='-b':
            try:
                red   = int(argList['-r'].value)
                green = int(argList['-g'].value)
                blue  = int(argList['-b'].value)
            except Exception as e:
                print(e)
                break

            print("Colour changed to:\n%d, %d, %d" %(red, green, blue))
            RGBpi.changeSettings(ser,
                    [-1, -1, -1, -1, -1, red, green, blue, -1, 6])
            break
        else:
            break
    return

profile.run('main()')
#main()

print('*/')
#print('var colour = "red";')
print('var error = "' + error + '";')
print('</script></body></html>')

