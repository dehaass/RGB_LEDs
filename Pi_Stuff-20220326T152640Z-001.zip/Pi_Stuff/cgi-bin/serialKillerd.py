import os
import grp
import signal
import daemon
import lockfile
import piSite


context = daemon.DaemonContext(
    working_directory='/home/stuart/',
    pidfile=lockfile.FileLock('/var/run/serialKiller.pid'),
    stdin='/tmp/shit.txt'
    )

"""
context.signal_map = {
    signal.SIGTERM: program_cleanup,
    signal.SIGHUP: 'terminate',
    signal.SIGUSR1: reload_program_config,
    }
"""

mail_gid = grp.getgrnam('stuart').gr_gid
context.gid = mail_gid


RGBpi.connectPi()

with context:
    RGBpi.doStuff()
