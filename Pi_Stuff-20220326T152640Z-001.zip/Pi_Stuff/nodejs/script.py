import sys

for line in sys.stdin:	
	print "lololol"
	print sys.argv[1]
