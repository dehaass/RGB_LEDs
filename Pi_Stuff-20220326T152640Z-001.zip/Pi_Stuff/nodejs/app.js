var PythonShell = require('python-shell');
PythonShell.defaultOptions = {
    pythonPath: '/usr/bin/python3',
    scriptPath: '/home/stuart/Scripts/',
}

var redOptions = {
	args: ["-c", "red"]
}

var rainbow = {
	args: ["-s", "rainbow"]
}

// Calls *.py - Runs
// var pyshell = new PythonShell('RGBpi.py', options);

var express = require('express');
var app = express();

app.use(express.static(__dirname + '/public'));

app.get('/', function (req, res) {
	res.send('Hello World');
});

app.post('/rainbow', function(req,res) {
	console.log("rainbow");
	PythonShell.run('RGBpi.py', rainbow, function(err, results){
		if (err) throw err;
		
		console.log('results: %j', results);
                console.log('finished');
        });
});

app.post('/red', function(req, res) {
	console.log("running");
//	var value;
//	value = request.body.value;
//	var option = {args: [value]};
	PythonShell.run('RGBpi.py', redOptions, function(err, results){
		if (err) throw err;

		console.log('results: %j', results);
		console.log('finished');
	});
/*
pyshell.send('hello');

pyshell.on('message', function (message) {
  // received a message sent from the Python script (a simple "print" statement)
  console.log(message);
});

// end the input stream and allow the process to exit
pyshell.end(function (err) {
  if (err) throw err;
  console.log('finished');
});
*/
});

app.listen(3000, function() {
	console.log('Example app listening on part 3000!');
});
